package self.bank;

public class Customer {
	private String name;
	private int ssn; //주민번호
	private Account account;
	private Address address;
	
	
	
}
