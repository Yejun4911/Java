package self.bank;

public class Address {
	
}
